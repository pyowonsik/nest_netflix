import { Reflector } from '@nestjs/core';

export const RBAC = Reflector.createDecorator();
